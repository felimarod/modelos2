/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package udistrital.edu.co.mod2.model;

import java.awt.Graphics;

/**
 *
 * @author carlos
 */
public interface Dibujable {
    public void dibujar(Graphics g);
}
